﻿namespace UIWidgets.Examples
{
	using System.Collections.Generic;
	using UIWidgets;

	/// <summary>
	/// TableList sample.
	/// </summary>
	public class TableList : ListViewCustom<TableListComponent, List<int>>
	{
	}
}