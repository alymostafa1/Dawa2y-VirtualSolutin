﻿namespace UIWidgets.Examples
{
	using UIWidgets;

	/// <summary>
	/// Simple table sample.
	/// </summary>
	public class SimpleTable : ListViewCustomHeight<SimpleTableComponent, SimpleTableItem>
	{
	}
}