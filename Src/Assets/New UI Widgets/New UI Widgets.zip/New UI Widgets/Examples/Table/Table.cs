﻿namespace UIWidgets.Examples
{
	using UIWidgets;

	/// <summary>
	/// Table sample.
	/// </summary>
	public class Table : ListViewCustom<TableRowComponent, TableRow>
	{
	}
}