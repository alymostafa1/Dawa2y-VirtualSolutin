﻿namespace UIWidgets.Examples
{
	using UIWidgets;

	/// <summary>
	/// TreeViewSample.
	/// </summary>
	public class TreeViewSample : TreeViewCustom<TreeViewSampleComponent, ITreeViewSampleItem>
	{
	}
}