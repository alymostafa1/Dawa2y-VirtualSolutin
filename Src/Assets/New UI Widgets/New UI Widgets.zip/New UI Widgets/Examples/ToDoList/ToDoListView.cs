﻿namespace UIWidgets.Examples.ToDoList
{
	using UIWidgets;

	/// <summary>
	/// ToDoListView.
	/// </summary>
	public class ToDoListView : ListViewCustomHeight<ToDoListViewComponent, ToDoListViewItem>
	{
	}
}