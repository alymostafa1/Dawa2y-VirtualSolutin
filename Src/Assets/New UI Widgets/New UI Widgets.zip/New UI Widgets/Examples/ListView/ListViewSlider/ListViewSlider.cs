﻿namespace UIWidgets.Examples
{
	using UIWidgets;

	/// <summary>
	/// ListView with sliders.
	/// </summary>
	public class ListViewSlider : ListViewCustom<ListViewSliderComponent, ListViewSliderItem>
	{
	}
}