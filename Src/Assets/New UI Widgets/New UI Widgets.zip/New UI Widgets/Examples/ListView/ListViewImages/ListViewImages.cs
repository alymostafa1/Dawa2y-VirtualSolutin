﻿namespace UIWidgets.Examples
{
	using UIWidgets;

	/// <summary>
	/// ListViewImages sample.
	/// </summary>
	public class ListViewImages : ListViewCustomHeight<ListViewImagesComponent, ListViewImagesItem>
	{
	}
}