﻿namespace UIWidgets.Examples
{
	/// <summary>
	/// Test script renaming.
	/// </summary>
	public class TestScriptRenamed
	{
	}
}