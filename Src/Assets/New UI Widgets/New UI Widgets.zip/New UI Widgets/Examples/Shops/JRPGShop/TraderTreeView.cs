﻿namespace UIWidgets.Examples.Shops
{
	using UIWidgets;

	/// <summary>
	/// TraderTreeView.
	/// </summary>
	public class TraderTreeView : TreeViewCustom<TraderTreeViewComponent, JRPGOrderLine>
	{
	}
}