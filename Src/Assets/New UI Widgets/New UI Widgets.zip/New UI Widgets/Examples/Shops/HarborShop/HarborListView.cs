﻿namespace UIWidgets.Examples.Shops
{
	using UIWidgets;

	/// <summary>
	/// Harbor list view.
	/// </summary>
	public class HarborListView : ListViewCustom<HarborListViewComponent, HarborOrderLine>
	{
	}
}