﻿namespace UIWidgets.Examples
{
	using UnityEngine.Events;

	/// <summary>
	/// PlaylistCurrent event.
	/// </summary>
	public class PlaylistCurrentEvent : UnityEvent<int>
	{
	}
}