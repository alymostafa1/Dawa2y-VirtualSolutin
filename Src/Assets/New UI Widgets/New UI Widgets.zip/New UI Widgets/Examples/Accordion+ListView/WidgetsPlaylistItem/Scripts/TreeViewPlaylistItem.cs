namespace UIWidgets.Examples.Widgets
{
	/// <summary>
	/// TreeView for the PlaylistItem.
	/// </summary>
	public class TreeViewPlaylistItem : UIWidgets.TreeViewCustom<TreeViewComponentPlaylistItem, UIWidgets.Examples.PlaylistItem>
	{
	}
}