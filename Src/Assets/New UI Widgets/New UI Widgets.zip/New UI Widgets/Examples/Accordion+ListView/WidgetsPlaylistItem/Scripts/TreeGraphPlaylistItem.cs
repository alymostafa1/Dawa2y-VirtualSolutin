namespace UIWidgets.Examples.Widgets
{
	/// <summary>
	/// TreeGraph for the PlaylistItem.
	/// </summary>
	public class TreeGraphPlaylistItem : UIWidgets.TreeGraphCustom<UIWidgets.Examples.PlaylistItem, TreeGraphComponentPlaylistItem>
	{
	}
}