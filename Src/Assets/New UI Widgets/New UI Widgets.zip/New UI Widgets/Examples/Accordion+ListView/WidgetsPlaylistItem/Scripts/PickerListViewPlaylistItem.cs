namespace UIWidgets.Examples.Widgets
{
	/// <summary>
	/// Picker from ListView for the PlaylistItem.
	/// </summary>
	public class PickerListViewPlaylistItem : UIWidgets.PickerListViewCustom<ListViewPlaylistItem, ListViewComponentPlaylistItem, UIWidgets.Examples.PlaylistItem, PickerListViewPlaylistItem>
	{
	}
}