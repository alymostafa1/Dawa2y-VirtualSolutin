namespace UIWidgets.Examples.Widgets
{
	/// <summary>
	/// Combobox for the PlaylistItem.
	/// </summary>
	public class ComboboxPlaylistItem : UIWidgets.ComboboxCustom<ListViewPlaylistItem, ListViewComponentPlaylistItem, UIWidgets.Examples.PlaylistItem>
	{
	}
}