﻿namespace UIWidgets.Examples
{
	using UIWidgets;
	using UnityEngine;

	/// <summary>
	/// TileViewIcons.
	/// </summary>
	public class TileViewIcons : TileViewCustom<ListViewIconsItemComponent, ListViewIconsItemDescription>
	{
	}
}