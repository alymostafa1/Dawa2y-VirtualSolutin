﻿namespace UIWidgets.Examples
{
	using UIWidgets;

	/// <summary>
	/// SimpleTileView.
	/// </summary>
	public class SimpleTileView : TileViewCustom<SimpleTileViewComponent, SimpleTileViewItem>
	{
	}
}