﻿namespace UIWidgets.Examples
{
	using UIWidgets;

	/// <summary>
	/// TileViewList.
	/// </summary>
	public class TileViewList : TileViewCustomSize<ListViewIconsItemComponent, ListViewIconsItemDescription>
	{
	}
}