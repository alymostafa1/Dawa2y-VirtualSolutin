﻿namespace UIWidgets
{
	using System;
	using UnityEngine.Events;

	/// <summary>
	/// AutocompleteEvent.
	/// </summary>
	[Serializable]
	public class AutocompleteEvent : UnityEvent<string>
	{
	}
}