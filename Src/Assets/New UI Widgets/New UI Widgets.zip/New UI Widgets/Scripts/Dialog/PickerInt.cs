﻿namespace UIWidgets
{
	using UnityEngine;

	/// <summary>
	/// PickerInt.
	/// </summary>
	public class PickerInt : PickerListViewCustom<ListViewInt, ListViewIntComponentBase, int, PickerInt>
	{
	}
}