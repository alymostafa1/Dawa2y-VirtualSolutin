﻿namespace UIWidgets
{
	using UnityEngine;

	/// <summary>
	/// PickerIcons.
	/// </summary>
	public class PickerIcons : PickerListViewCustom<ListViewIcons, ListViewIconsItemComponent, ListViewIconsItemDescription, PickerIcons>
	{
	}
}