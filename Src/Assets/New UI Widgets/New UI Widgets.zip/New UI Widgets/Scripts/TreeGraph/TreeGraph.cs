﻿namespace UIWidgets
{
	/// <summary>
	/// TreeGraph.
	/// </summary>
	public class TreeGraph : TreeGraphCustom<TreeViewItem, TreeGraphComponentIcons>
	{
	}
}