﻿namespace UIWidgets
{
	using UnityEngine.UI;

	/// <summary>
	/// Tab button.
	/// </summary>
	public class TabButton : Button
	{
	}
}