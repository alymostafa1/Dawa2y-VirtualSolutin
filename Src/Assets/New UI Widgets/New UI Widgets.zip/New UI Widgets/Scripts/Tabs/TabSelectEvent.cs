﻿namespace UIWidgets
{
	using System;
	using UnityEngine.Events;

	/// <summary>
	/// TabSelectEvent.
	/// </summary>
	[Serializable]
	public class TabSelectEvent : UnityEvent<int>
	{
	}
}