﻿namespace UIWidgets
{
	/// <summary>
	/// Alias for SidebarHandle.
	/// </summary>
	public class SlideBlockHandle : SidebarHandle
	{
	}
}