﻿namespace UIWidgets
{
	/// <summary>
	/// Alias for Sidebar.
	/// </summary>
	public class SlideBlock : Sidebar
	{
	}
}